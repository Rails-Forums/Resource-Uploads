Notice: Change user.username to user."What you want" before using
Make sure to put the files in there corresponding folders hence the folder labels.

Also these conversation files are for Rails 7 with turbo.
