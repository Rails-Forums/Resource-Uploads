module ConversationsHelper
  #def check_convo
  #  if current_user.sender_id  OR if current_user.receiver_id
  #  else
  #    redirect_to root_path, notice: "You do not have access to this"
  #  end
#  end
end
